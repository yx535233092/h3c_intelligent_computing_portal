EXCEL_SERVICE_URL = "http://excel-service/v1"
AUTH_SERVICE_URL = "http://auth-service/v1"
REPORT_SERVICE_URL = "http://report-service/v2"

PARSE_EXCEL_ENDPOINT = f"{EXCEL_SERVICE_URL}/parse"
CHECK_TOKEN_ENDPOINT = f"{AUTH_SERVICE_URL}/check"

# 结尾加不加 / 都可以

MINERU_URL = "http://192.168.10.24:27862"
MONKEYOCR_URL = ""
