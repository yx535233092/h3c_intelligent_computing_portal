export default function Logo() {
  return <img src="/h3c-logo.png" alt="logo" className="h-7" />;
}
