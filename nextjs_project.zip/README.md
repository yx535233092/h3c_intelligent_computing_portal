# **H3C 智算服务平台门户**

## 项目架构

⎋ 前端框架：Nextjs  
css 框架：TailwindCss

## 项目脚本

```bash
# 安装依赖
npm install

# 运行项目
npm run dev
```
